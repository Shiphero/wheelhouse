UNDEFINED_VALUE = object()

__all__ = ("UNDEFINED_VALUE",)
