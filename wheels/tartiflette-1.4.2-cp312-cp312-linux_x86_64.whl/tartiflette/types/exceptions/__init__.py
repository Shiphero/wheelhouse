from tartiflette.types.exceptions.tartiflette import TartifletteError

__all__ = ("TartifletteError",)
